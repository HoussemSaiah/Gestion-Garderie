package acteur;

import java.util.Scanner;

public class Garderie {
	private String nom;
	private String matricule;

	
	public Garderie() {
		nom = "Garderie rahma";
		matricule = "zdaz156465zd";
	}

	public void update_d() {
        int c = 0;
        System.out.println("\n\t1- Voulez vous changer le nom de la garderie: ");
        System.out.println("\n\t2- Voulez vous changer la matricule de la garderie: ");

		Scanner sr = new Scanner(System.in);
		
        System.out.println("\nDonner le numero de votre choix : ");
        c = sr.nextInt();
        switch(c) {

        case 1:
            System.out.println(" Donner le nouveau nom: ");
            nom="";
            nom= sr.nextLine();
            nom+=sr.nextLine();
            break;
        case 2 :
            System.out.println(" Donner une nouvelle matricule: ");
            matricule = sr.next();
            break;
        default:
            System.out.println("choix INVALIDE.\n");
            break;
        }
    }

	public void affiche() {
		System.out.println("\n Nom= '" + nom + "'\n Matricule=" + matricule) ;
	}
	@Override
	public String toString() {
		return "nom=" + nom + ", matricule=" + matricule ;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public String getMatricule() {
		return matricule;
	}


	public void setMatricule(String matricule) {
		this.matricule = matricule;
	}
}
