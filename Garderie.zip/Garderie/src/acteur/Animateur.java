package acteur;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Vector;

public class Animateur extends Person {
	private String cin;
	private ArrayList<Cours> listeCoursAni = new ArrayList<Cours>();
	int nbCours =0;

	public Animateur(String nom, String prenom, String prenom_pere, String tel, Date date_N, Adresse adresse,
			String cin) {
		super(nom, prenom, prenom_pere, tel, date_N, adresse);
		this.cin = cin;
	}
	
	public Animateur() {
	}


			Scanner sr = new Scanner(System.in);
			
	
	@Override
	public void add(Directeur d) {
		String num,code;
		 String mois,jour,annee;
		System.out.println("\nDonner le nom : ");
		setNom(sr.next());
		System.out.println("\nDonner le pr�nom : ");
		setPrenom(sr.next());
		System.out.println("\nDonner le pr�nom du p�re : ");
		setPrenom_pere(sr.next());
		do {
            System.out.println("\nDonner le num�ro de CIN: ");
            cin = sr.next();
            }while(!cin.matches("^[0-9]+$"));
        do {
            System.out.println("\nDonner le num�ro de t�l�phone: ");
            setTel(sr.next());
        }while(!(getTel().matches("^[0-9]+$")&& getTel().length()== 8));
       
		do {
			System.out.println("\nDonner la date de naissance : ");
			do {
			System.out.println("\nDonner le jour : ");
			jour = sr.next();
			}while(!jour.matches("^[0-9]+$"));
			do {
			System.out.println("\nDonner le mois : ");
			mois = sr.next();
			}while(!mois.matches("^[0-9]+$"));
			do {
			System.out.println("\nDonner l'annee : ");
			annee = sr.next();
			}while(!annee.matches("^[0-9]+$"));
        }while(!d.isValidDate(Integer.parseInt(jour), Integer.parseInt(mois), Integer.parseInt(annee)));
		setDate_N(new Date(jour, mois, annee));
		System.out.println("\nDonner l'adresse : ");
		do {
			System.out.println("\nDonner le num�ro rue/avenue : ");
			 num = sr.next();
        }while(!num.matches("^[0-9]+$"));
		System.out.println("\nDonner la d�signation de la rue/avenue : ");
		String designaton = sr.next();
		System.out.println("\nDonner le nom de la ville : ");
		String ville = sr.next();
		do {
			System.out.println("\nDonner le code postal  : ");
			code = sr.next();
        }while(!code.matches("^[0-9]+$"));
		System.out.println("\nDonner le gouvernorat : ");
		String gouvernorat = sr.next();
		setAdresse(new Adresse(num, designaton, ville, code, gouvernorat)) ;
		
		
		Vector v = d.getListeAnimateur();
		v.add(this);
		d.setListeAnimateur(v);
		
		System.out.println("\nAdded ");
		
	}

	@Override
	public void delete(Directeur d) {
		
		int i=0;
		while (i<listeCoursAni.size()) {
			listeCoursAni.get(i).delete(d);
		}	
		
		Vector<Animateur> vec = d.getListeAnimateur(); 
		vec.removeElement(this);
		d.setListeAnimateur(vec);
		

	}

	@Override
	public void update(Directeur d) {
		Cours cou;
		String num,mois,jour,annee,code;
        int i=0,choix = 0;
            System.out.println(" ------------------- MENU ----------------------------");
            System.out.println("\n\t  1- Changer le nom ");
            System.out.println("\n\t  2- Changer le pr�nom ");
            System.out.println("\n\t  3- Changer le pr�nom du p�re ");
            System.out.println("\n\t  4- Changer le num�ro de CIN ");
            System.out.println("\n\t  5- Changer le le num�ro de t�l�phone ");
            System.out.println("\n\t  6- Changer la date de naissance ");
            System.out.println("\n\t  7- Changer l'adresse ");

            System.out.println("\nDonner le numero de votre choix : ");
            choix = sr.nextInt();
            switch (choix) {

            case 1 :	System.out.println("\nDonner le nom : ");
						setNom(sr.next());
                break;
            case 2 :	System.out.println("\nDonner le pr�nom : ");
						setPrenom(sr.next());
                break;
            case 3 :	System.out.println("\nDonner le pr�nom du p�re : ");
						setPrenom_pere(sr.next());
                break;
            case 4 :	do {
				            System.out.println("\nDonner le num�ro de CIN : ");
				            cin = sr.next();
			            }while(!cin.matches("^[0-9]+$"));
						
            			while (i<listeCoursAni.size()) {
		        			cou = listeCoursAni.get(i);
		        			if(cou.getCin().equalsIgnoreCase(cin))
		        				cou.setCin(cin);
		        			i++;
		        		}	
			    break;
			case 5 : 	do {
				            System.out.println("\nDonner le num�ro de t�l�phone : ");
				            setTel(sr.next());
				        }while(!(getTel().matches("^[0-9]+$")&& getTel().length()== 8));
			    break;
			case 6 :	do {
							System.out.println("\nDonner la date de naissance : ");
							do {
							System.out.println("\nDonner le jour : ");
							jour = sr.next();
							}while(!jour.matches("^[0-9]+$"));
							do {
							System.out.println("\nDonner le mois : ");
							mois = sr.next();
							}while(!mois.matches("^[0-9]+$"));
							do {
							System.out.println("\nDonner l'annee : ");
							annee = sr.next();
							}while(!annee.matches("^[0-9]+$"));
				        }while(!d.isValidDate(Integer.parseInt(jour), Integer.parseInt(mois), Integer.parseInt(annee)));
						setDate_N(new Date(jour, mois, annee));
			    break;
			case 7 :	do {
							System.out.println("\nDonner le num�ro rue/avenue : ");
							 num = sr.next();
			           }while(!num.matches("^[0-9]+$"));
						System.out.println("\nDonner la d�signation de la rue/avenue : ");
						String designaton = sr.next();
						System.out.println("\nDonner le nom de la ville : ");
						String ville = sr.next();
						do {
							System.out.println("\nDonner le code postal  : ");
							code = sr.next();
			           }while(!code.matches("^[0-9]+$"));
						System.out.println("\nDonner le gouvernorat : ");
						String gouvernorat = sr.next();
						setAdresse(new Adresse(num, designaton, ville, code, gouvernorat)) ;
				    break;
			default:
                System.out.println("choix INVALIDE.\n");
                break;
            }

	}


	
	public String getCin() {
		return cin;
	}

	public void setCin(String cin) {
		this.cin = cin;
	}

	public ArrayList<Cours> getListeCoursAni() {
		return listeCoursAni;
	}

	public void setListeCoursAni(ArrayList<Cours> listeCoursAni) {
		this.listeCoursAni = listeCoursAni;
	}

	@Override
    public String toString() {
    return "|         CIN         |\t\t"+cin+"\n"+
    "+---------------------+----------------------------------------------------------------------------\n"+
    "|         NOM         |\t\t"+getNom()+"\n"+
    "+---------------------+----------------------------------------------------------------------------\n"+
    "|       PRENOM        |\t\t"+getPrenom()+"\n"+
    "+---------------------+----------------------------------------------------------------------------\n"+
    "|    PRENOM DU PERE   |\t\t"+getPrenom_pere()+"\n"+
    "+---------------------+----------------------------------------------------------------------------\n"+
    "|      TELEPHONE      |\t\t"+getTel()+"\n"+
    "+---------------------+----------------------------------------------------------------------------\n"+
    "|  DATE DE NAISSANCE  |\t\t"+getDate_N()+"\n"+
    "+---------------------+----------------------------------------------------------------------------\n"+
    "|       ADRESSE       |\t\t"+getAdresse()+"\n"+
    "+---------------------+----------------------------------------------------------------------------\n"+
    "|    LISTE DES COURS  |\t\t"+listeCoursAni+"\n"+
    "\n+-------------------------------------------------------------------------------------------------+\n"+
    "+-------------------------------------------------------------------------------------------------+\n";
    }

}
