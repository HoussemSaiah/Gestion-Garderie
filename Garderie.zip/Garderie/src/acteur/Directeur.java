package acteur;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Vector;
import java.io.*;


public class Directeur {
	
	static int MAX_VALID_YR = 9999;
    static int MIN_VALID_YR = 1800;
	private String userName;
	private String password;
	private Vector<Eleve> listeEleve = new Vector();
	private Vector<Classes> listeClasse = new Vector();
	private Vector<Cours> listeCours = new Vector();
	private Vector<Animateur> listeAnimateur = new Vector();
	
	
	public Directeur(String userName, String password) {
		this.userName = userName;
		this.password = password;
	}
	public Directeur() {
		userName = "salma";
		password = "123";
	}
		
			Scanner sr = new Scanner(System.in);
	
	public void update_d() {
        String a,b;
        System.out.println("Donner le nouveau username:");
        userName = sr.next();
        do {
	        System.out.println("Donner le nouveau mot de passe:");
	        a= sr.next();
	        System.out.println("Confirmer le nouveau mot de passe:");
	        b= sr.next();
        }while(!a.equalsIgnoreCase(b));
        password=a;
	}
	
	public void list_A() {
		System.out.println("------------------- liste des animateur -----------------------\n");
		for (int i = 0; i < this.listeAnimateur.size(); i++) {
			System.out.println((Animateur)listeAnimateur.get(i));
		}
	}
	public void list_C() {
		System.out.println("------------------- liste des Cours -----------------------\n");
		for (int i = 0; i < this.listeCours.size(); i++) {
			System.out.println(listeCours.get(i).afficheCours());
		}
	}
	public void list_E() {
		System.out.println("------------------- liste des Eleves -----------------------\n");
		for (int i = 0; i < this.listeEleve.size(); i++) {
			System.out.print("+----------------------------------------------------------+\n"+"|\t\t   Eleve n�"+i+1+"\t\t\t\t   |\n+----------------------------------------------------------+\n");
			System.out.println(listeEleve.get(i).afficheEleve());
		}
	}
	public void list_Ca() {
		System.out.println("------------------- liste des classes -----------------------\n");
		for (int i = 0; i < this.listeClasse.size(); i++) {
			System.out.println((Classes)listeClasse.get(i));
		}
	}
	public void update_e() {
		System.out.println("donner le cin de son pere :");
		String cin = sr.next();
		int i=0;
		while (i<listeEleve.size()) {
			if (listeEleve.get(i).getCinP().equalsIgnoreCase(cin) ) {
				
			}
			i++;
		} 
	}
	public void statistique() {
		ArrayList<Cours> list_c;
		System.out.println("Le nombre des eleves est : "+listeEleve.size());
		System.out.println("Le nombre des animateur est : "+listeAnimateur.size());
		System.out.println("Le nombre des classes est : "+listeClasse.size());
		System.out.println("Le nombre des cours est : "+listeCours.size()+"\n");
		if(listeEleve.size() !=0) {
			for(int i=0;i<listeCours.size();i++) {
				int nb=0;
				for(int j=0;j<listeClasse.size();j++) {
					list_c = listeClasse.get(j).getCours();
					int k=0;
					while(k<list_c.size()) {
						if(list_c.indexOf(listeCours.get(i))>= 0  ) {
							System.out.println(listeClasse.get(j).etudiants.size());
							nb+=listeClasse.get(j).etudiants.size();
							break;
						}
						k++;
					}
				}
				System.out.println("Le cours  : "+listeCours.get(i).getDesignation()+" ( "+listeCours.get(i).getCode()+" ): "+(nb*100)/listeEleve.size()+"%");	
		}
			
			
		}
	}
	static boolean isLeap(int year)
    {
        return (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0));
    }
	static boolean isValidDate(int d,int m,int y)
	{
			if (y > MAX_VALID_YR ||y < MIN_VALID_YR)
				return false;
			if (m < 1 || m > 12)
				return false;
			if (d < 1 || d > 31)
				return false;
			if (m == 2)
			{
				if (isLeap(y))
					return (d <= 29);
				else
					return (d <= 28);
			}

			if (m == 4 || m == 6 || m == 9 || m == 11)
				return (d <= 30);
			
			return true;
	}

	
	public Vector<Eleve> getListeEleve() {
		return listeEleve;
	}
	public void setListeEleve(Vector<Eleve> listeEleve) {
		this.listeEleve = listeEleve;
	}
	public Vector<Classes> getListeClasse() {
		return listeClasse;
	}
	public void setListeClasse(Vector<Classes> listeClasse) {
		this.listeClasse = listeClasse;
	}
	public Vector<Cours> getListeCours() {
		return listeCours;
	}
	public void setListeCours(Vector<Cours> listeCours) {
		this.listeCours = listeCours;
	}
	public Vector<Animateur> getListeAnimateur() {
		return listeAnimateur;
	}
	public void setListeAnimateur(Vector<Animateur> listeAnimateur) {
		this.listeAnimateur = listeAnimateur;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

}
