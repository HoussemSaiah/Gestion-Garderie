package acteur;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Vector;

public class Cours {

	private int code;
	private String designation,cin;
	private double prix;

	public Cours(int code, String designation, String cin, double prix) {
		this.code = code;
		this.designation = designation;
		this.cin = cin;
		this.prix = prix;
	}
	public Cours() {

	}


	Scanner sr = new Scanner(System.in);
	
	public Animateur rechercheAnimateur (Directeur d,String nom, String prenom) {
		
		Vector<Animateur> vec = d.getListeAnimateur(); 
		int i=0;
		while (i<vec.size()) {
			if ( (vec.get(i).getNom().equalsIgnoreCase(nom)) &&  (vec.get(i).getPrenom().equalsIgnoreCase(prenom))) {
				return vec.get(i);
			}
			i++;
		} 
		return null;
	}
	public Animateur existAnimateur(Directeur d ,String cin) {
		Vector<Animateur> vec = d.getListeAnimateur(); 
		int i=0;
		while (i<vec.size()) {
			if (vec.get(i).getCin().equalsIgnoreCase(cin) ){
				return vec.get(i);
			}
			i++;
		} 
		return null;
	}
	public void add_C(Directeur d ) {
		String nom,prenom,prix1;
		ArrayList<Cours> cours = new ArrayList<Cours>();
		Animateur a ;
		do {
			System.out.println("Donner le nom du animateur : ");
			nom = sr.next();
			System.out.println("Donner le prenom du animateur : ");
			prenom = sr.next();
		}while((a=rechercheAnimateur(d,nom, prenom))==null);
	 
		cin = a.getCin();
		System.out.println("\nDonner le un code : ");
		code = sr.nextInt();
		System.out.println("\nDonner la d�signation : ");
		designation = sr.next();
		do{
		System.out.println("\nDonner le prix : ");
		prix1 = sr.next();
		}while(!prix1.matches("^[0-9]+$"));
		prix = Integer.parseInt(prix1);
		cours = a.getListeCoursAni();
		cours.add(this);
		a.setListeCoursAni(cours);
		
		Vector v = d.getListeCours();
		v.add(this);
		d.setListeCours(v);
	}
	public void delete(Directeur d) {
		
		Vector<Classes> vect = d.getListeClasse(); 
		int i=0,k;
		ArrayList<Cours> cours;
		ArrayList<String> ani;
		Classes c;
		Animateur a;
		/// delete from classes (cours - animateur ) 
		do {
			c=vect.get(i);
			cours = c.getCours();
			ani=c.getAnimateurs();
			k=cours.indexOf(this);
			if (k>=0) {
				cours.remove(this);
				ani.remove(k);
				c.setAnimateurs(ani);
				c.setCours(cours);
			}				
			i++;
		}while (i<vect.size());
		/// delete from animateur
		a = existAnimateur(d,cin);
		cours = a.getListeCoursAni();
		cours.remove(this);
		a.setListeCoursAni(cours);
		//  delete from listeCours (vector)
		Vector<Cours> vec = d.getListeCours(); 
		vec.removeElement(this);
		d.setListeCours(vec);
	}
	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public double getPrix() {
		return prix;
	}

	public void setPrix(double prix) {
		this.prix = prix;
	}

	public String getCin() {
		return cin;
	}

	public void setCin(String cin) {
		this.cin = cin;
	}
	public String afficheCours() {
		 return "[ code=" + code + ", designation=" + designation + ", cin=" + cin + ", prix=" + prix+"]" ;
    } 
	
	@Override
    public String toString() {
        return "\n\t\t\t\t[ code=" + code + ", designation=" + designation + ", cin=" + cin + ", prix=" + prix+"]" ;
    }

}
