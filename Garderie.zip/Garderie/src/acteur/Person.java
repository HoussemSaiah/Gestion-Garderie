package acteur;

public abstract class Person {
	private String nom;
	private String prenom;
	private String prenom_pere;
	private String tel;
	private Date date_N;
	private Adresse adresse;
	
	public Person(String nom, String prenom, String prenom_pere, String tel, Date date_N, Adresse adresse) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.prenom_pere = prenom_pere;
		this.tel = tel;
		this.date_N = date_N;
		this.adresse = adresse;
	}
	
	public Person() {
	}

	public  abstract  void add(Directeur d) ;
	public  abstract  void delete(Directeur d) ;
	public  abstract  void update(Directeur d) ;
	
	
	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getPrenom_pere() {
		return prenom_pere;
	}

	public void setPrenom_pere(String prenom_pere) {
		this.prenom_pere = prenom_pere;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public Date getDate_N() {
		return date_N;
	}

	public void setDate_N(Date date_N) {
		this.date_N = date_N;
	}

	public Adresse getAdresse() {
		return adresse;
	}

	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}


}
