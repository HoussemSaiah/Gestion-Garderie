package acteur;

public class Adresse {
	private String num;
	private String designaton;
	private String ville;
	private String cdePostal;
	private String gouvernorat;
	
	public Adresse(String num, String designaton, String ville, String cdePostal, String gouvernorat) {
		this.num = num;
		this.designaton = designaton;
		this.ville = ville;
		this.cdePostal = cdePostal;
		this.gouvernorat = gouvernorat;
	}
	
	@Override
	public String toString() {
		return "num=" + num + ", designaton=" + designaton + ", ville=" + ville + ", cdePostal=" + cdePostal
				+ ", gouvernorat=" + gouvernorat ;
	}
}
