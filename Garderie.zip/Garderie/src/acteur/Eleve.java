package acteur;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Vector;

public class Eleve extends Person{
	private String prenom_g_pere;
	private String prenom_mere;
	private String nom_mere;
	private String niveau_S;
	private double prix;
	private String cinP;
	private String nClasse;
	
	public Eleve(String nom, String prenom, String prenom_pere, String tel, Date date_N, Adresse adresse,
			String prenom_g_pere, String prenom_mere, String nom_mere, String niveau_S, String cinP,String nClasse) {
		super(nom, prenom, prenom_pere, tel, date_N, adresse);
		this.prenom_g_pere = prenom_g_pere;
		this.prenom_mere = prenom_mere;
		this.nom_mere = nom_mere;
		this.niveau_S = niveau_S;
		this.cinP = cinP;
		this.nClasse = nClasse;
	}
	public Eleve () {
	}

	Scanner sr = new Scanner(System.in);
	
	public Classes testClasse(Directeur d, String nom) {
		
		Vector<Classes> vec = d.getListeClasse(); 
		int i=0;
		while (i<vec.size()) {
			if ( vec.get(i).getNom().equalsIgnoreCase(nom)) {
				return vec.get(i);
			}
			i++;
		} 
		return null;
	}
	
	@Override
	public void add(Directeur d) {
		String nom_c;
		Classes c ;
		String num,code,mois,jour,annee;
		ArrayList<Eleve> etudiants = new ArrayList<Eleve>();
		do {
			System.out.println("Donner le nom du classe : ");
			nom_c = sr.next();
		}while((c=testClasse(d,nom_c))==null);
		if (c.getNbEleve() <= 20) {
			System.out.println("\nDonner le nom : ");
			setNom(sr.next());
			System.out.println("\nDonner le pr�nom : ");
			setPrenom(sr.next());
			System.out.println("\nDonner le pr�nom du p�re : ");
			setPrenom_pere(sr.next());
			System.out.println("\nDonner le pr�nom de son grand p�re de cot� de son p�re : ");
			prenom_g_pere = sr.next();
			System.out.println("\nDonner le nom de sa m�re : ");
			nom_mere = sr.next();
			System.out.println("\nDonner le pr�nom de sa m�re : ");
			prenom_mere = sr.next();
			do {
	            System.out.println("\nDonner le num�ro de CIN de son p�re : ");
	            cinP = sr.next();
	            }while(!cinP.matches("^[0-9]+$"));
	        do {
	            System.out.println("\nDonner le num�ro de t�l�phone de son p�re : ");
	            setTel(sr.next());
	        }while(!(getTel().matches("^[0-9]+$")&& getTel().length()== 8));
	        do {
				System.out.println("\nDonner la date de naissance : ");
				do {
				System.out.println("\nDonner le jour : ");
				jour = sr.next();
				}while(!jour.matches("^[0-9]+$"));
				do {
				System.out.println("\nDonner le mois : ");
				mois = sr.next();
				}while(!mois.matches("^[0-9]+$"));
				do {
				System.out.println("\nDonner l'annee : ");
				annee = sr.next();
				}while(!annee.matches("^[0-9]+$"));
	        }while(!d.isValidDate(Integer.parseInt(jour), Integer.parseInt(mois), Integer.parseInt(annee)));
			setDate_N(new Date(jour, mois, annee));			
			System.out.println("\nDonner l'adresse : ");
			do {
				System.out.println("\nDonner le num�ro rue/avenue : ");
				 num = sr.next();
            }while(!num.matches("^[0-9]+$"));
			System.out.println("\nDonner la d�signation de la rue/avenue : ");
			String designaton = sr.next();
			System.out.println("\nDonner le nom de la ville : ");
			String ville = sr.next();
			do {
				System.out.println("\nDonner le code postal  : ");
				code = sr.next();
            }while(!code.matches("^[0-9]+$"));
			System.out.println("\nDonner le gouvernorat : ");
			String gouvernorat = sr.next();
			setAdresse(new Adresse(num, designaton, ville, code, gouvernorat)) ;
			
			System.out.println("\nDonner le niveau scolaire : ");
			niveau_S = sr.next();
			nClasse = c.getNom();			
			prix=c.getPrix();
			Vector v = d.getListeEleve();
			v.add(this);
			d.setListeEleve(v);
			
			etudiants = c.getEtudiants();
			etudiants.add(this);
			c.setEtudiants(etudiants);
			
			int i = c.getNbEleve();
			i++;
			c.setNbEleve(i);
			
			System.out.println("\nAdded ");
		}else {
			System.out.println("\nClasse plaine ");
		}
		
	}


	public Classes rechercheClasses(Directeur d ,String nomCla) {
		Vector<Classes> vec = d.getListeClasse(); 
		int i=0;
		while (i<vec.size()) {
			if ( vec.get(i).getNom().equalsIgnoreCase(nomCla)) {
				return vec.get(i);
			}
			i++;
		} 
		return null;
		
	}
	@Override
	public void delete(Directeur d) {

		Classes c;
		// delete eleves from classes
		c = rechercheClasses(d, nClasse);
		ArrayList<Eleve> listeE = c.getEtudiants();
		listeE.remove(this);
		c.setEtudiants(listeE);
		// delete eleves from vector
		Vector<Eleve> vec = d.getListeEleve(); 
		vec.removeElement(this);
		d.setListeEleve(vec);
	}

	@Override
	public void update(Directeur d) {
		Classes c ;
		String nom_c;
		String num,code,jour,mois,annee;
        int choix = 0;
            System.out.println(" ------------------- MENU GESTION COURS ----------------------------");
            System.out.println("\n\t  1- Changer le nom ");
            System.out.println("\n\t  2- Changer le pr�nom ");
            System.out.println("\n\t  3- Changer le pr�nom du p�re ");
            System.out.println("\n\t  4- Changer le pr�nom de son grand p�re ");
            System.out.println("\n\t  5- Changer le nom de sa m�re ");
            System.out.println("\n\t  6- Changer le pr�nom de sa m�re ");
            System.out.println("\n\t  7- Changer le num�ro de CIN de son p�re ");
            System.out.println("\n\t  8- Changer le le num�ro de t�l�phone de son p�re ");
            System.out.println("\n\t  9- Changer la date de naissance ");
            System.out.println("\n\t 10- Changer l'adresse ");
            System.out.println("\n\t 11- Changer le niveau scolaire ");
            System.out.println("\n\t 12- Changer le classe ");

            System.out.println("\nDonner le numero de votre choix : ");
            choix = sr.nextInt();
            switch (choix) {

            case 1 :	System.out.println("\nDonner le nom : ");
						setNom(sr.next());
                break;
            case 2 :	System.out.println("\nDonner le pr�nom : ");
						setPrenom(sr.next());
                break;
            case 3 :	System.out.println("\nDonner le pr�nom du p�re : ");
						setPrenom_pere(sr.next());
                break;
            case 4 :	System.out.println("\nDonner le pr�nom de son grand p�re de cot� de son p�re : ");
						prenom_g_pere = sr.next();
			    break;
			case 5 : 	System.out.println("\nDonner le nom de sa m�re : ");
						nom_mere = sr.next();
			    break;
			case 6 :	System.out.println("\nDonner le pr�nom de sa m�re : ");
						prenom_mere = sr.next();
			    break;
			case 7 :	do {
				            System.out.println("\nDonner le num�ro de CIN de son p�re : ");
				            cinP = sr.next();
			            }while(!cinP.matches("^[0-9]+$"));
				    break;
			case 8 : 	do {
				            System.out.println("\nDonner le num�ro de t�l�phone de son p�re : ");
				            setTel(sr.next());
				        }while(!(getTel().matches("^[0-9]+$")&& getTel().length()== 8));
			    break;
			case 9 :	do {
							System.out.println("\nDonner la date de naissance : ");
							do {
							System.out.println("\nDonner le jour : ");
							jour = sr.next();
							}while(!jour.matches("^[0-9]+$"));
							do {
							System.out.println("\nDonner le mois : ");
							mois = sr.next();
							}while(!mois.matches("^[0-9]+$"));
							do {
							System.out.println("\nDonner l'annee : ");
							annee = sr.next();
							}while(!annee.matches("^[0-9]+$"));
				        }while(!d.isValidDate(Integer.parseInt(jour), Integer.parseInt(mois), Integer.parseInt(annee)));
						setDate_N(new Date(jour, mois, annee));
			    break;
			case 10 :	
						do {
							System.out.println("\nDonner le num�ro rue/avenue : ");
							 num = sr.next();
			            }while(!num.matches("^[0-9]+$"));
						System.out.println("\nDonner la d�signation de la rue/avenue : ");
						String designaton = sr.next();
						System.out.println("\nDonner le nom de la ville : ");
						String ville = sr.next();
						do {
							System.out.println("\nDonner le code postal  : ");
							code = sr.next();
			            }while(!code.matches("^[0-9]+$"));
						System.out.println("\nDonner le gouvernorat : ");
						String gouvernorat = sr.next();
						setAdresse(new Adresse(num, designaton, ville, code, gouvernorat)) ;
				    break;
			case 11 : 	System.out.println("\nDonner le niveau scolaire : ");
						niveau_S = sr.next();
			    break;
			case 12 : 	do {
							System.out.println("Donner le nom du classe : ");
							nom_c = sr.next();
						}while((c=testClasse(d,nom_c))==null);
					break;
			default:
                System.out.println("choix INVALIDE.\n");
                break;
            }
       
		
	}


	public String getPrenom_g_pere() {
		return prenom_g_pere;
	}

	public void setPrenom_g_pere(String prenom_g_pere) {
		this.prenom_g_pere = prenom_g_pere;
	}

	public String getPrenom_mere() {
		return prenom_mere;
	}

	public void setPrenom_mere(String prenom_mere) {
		this.prenom_mere = prenom_mere;
	}

	public String getNom_mere() {
		return nom_mere;
	}

	public void setNom_mere(String nom_mere) {
		this.nom_mere = nom_mere;
	}

	public String getNiveau_S() {
		return niveau_S;
	}

	public void setNiveau_S(String niveau_S) {
		this.niveau_S = niveau_S;
	}

	public double getPrix() {
		return prix;
	}

	public void setPrix(double prix) {
		this.prix = prix;
	}

	public String getCinP() {
		return cinP;
	}

	public void setCinP(String cinP) {
		this.cinP = cinP;
	}	
	
	public String getnClasse() {
		return nClasse;
	}

	public void setnClasse(String nClasse) {
		this.nClasse = nClasse;
	}

	public String afficheEleve() {
		return   
				
				
				
				"|         NOM         |\t\t"+getNom()+"\n"+
		   	     "+---------------------+--------------------------------------\n"+
		         "|        PRENOM       |\t\t"+getPrenom()+"\n"+
		         "+---------------------+--------------------------------------\n"+
		         "|   PRENOM DU PERE    |\t\t"+getPrenom_pere()+"\n"+
		         "+---------------------+--------------------------------------\n"+
		         "|PRENOM DU GRAND PERE |\t\t"+ prenom_g_pere+"\n"+
		         "+---------------------+--------------------------------------\n"+
		         "|    NOM DE LA MERE   |\t\t"+nom_mere+"\n"+
		         "+---------------------+--------------------------------------\n"+
		         "|  PRENOM DE LA MERE  |\t\t"+prenom_mere+"\n"+
		         "+---------------------+--------------------------------------\n"+
		         "|    CIN DU PARENT    |\t\t"+cinP+"\n"+
		         "+---------------------+--------------------------------------\n"+
		         "|      TELEPHONE      |\t\t"+getTel()+"\n"+
		         "+---------------------+--------------------------------------\n"+
		         "|  DATE DE NAISSANCE  |\t\t"+getDate_N()+"\n"+
		         "+---------------------+--------------------------------------\n"+
		         "|      ADRESSE        |\t\t"+getAdresse()+"\n"+
		         "+---------------------+--------------------------------------\n"+
		         "|   NIVEAU SCOLAIRE   |\t\t"+niveau_S+"\n"+
		         "+---------------------+--------------------------------------\n"+
		         "|        PRIX         |\t\t"+prix+"\n"+
		         "+---------------------+--------------------------------------\n"+
		         "|  NOM DE LA CLASSE   |\t\t"+nClasse+"\n"+
		         "\n+-------------------------------------------------------------------------------------------------+\n"+
		         "+-------------------------------------------------------------------------------------------------+\n";
		
	}

	
	@Override
	public String toString() {
	
		
		return "\n\t\t\t\t[nom=" + getNom() +", Prenom=" + getPrenom()+ ", cinP=" + cinP  + "]";
		
		
	}

	
	
}
