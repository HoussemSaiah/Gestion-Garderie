package acteur;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Vector;

public class Classes {
	private String nom;
	ArrayList<Eleve> etudiants = new ArrayList<Eleve>();
	ArrayList<Cours> cours = new ArrayList<Cours>();
	ArrayList<String> animateurs = new ArrayList<String>();
	public static int  nbEleve = 0;
	private double prix;

	public Classes(String nom, ArrayList<Cours> cours, ArrayList<String> animateurs) {
		super();
		this.nom = nom;
		this.cours = cours;
		this.animateurs = animateurs;
	}
	public Classes() {

	}


	Scanner sr = new Scanner(System.in);
	
	public Cours rechercheCours (Directeur d,int code) {
		
		Vector<Cours> vec = d.getListeCours(); 
		int i=0;
		while (i<vec.size()) {
			if ( vec.get(i).getCode() == code) {
				return vec.get(i);
			}
			i++;
		} 
		return null;
	}
	public Classes rechercheClasse(Directeur d, String nom) {
		
		Vector<Classes> vec = d.getListeClasse(); 
		int i=0;
		while (i<vec.size()) {
			if ( vec.get(i).getNom().equalsIgnoreCase(nom)) {
				return vec.get(i);
			}
			i++;
		} 
		return null;
	}
	public Eleve rechercheEleve (Directeur d ,String cinP,String prenom,String nom) {
		
		Vector<Eleve> vec = d.getListeEleve(); 
		int i=0;
		while (i<vec.size()) {
			if ( vec.get(i).getCinP().equalsIgnoreCase(cinP) && vec.get(i).getPrenom().equalsIgnoreCase(prenom) && vec.get(i).getNom().equalsIgnoreCase(nom)) {
				return vec.get(i);
			}
			i++;
		} 
		return null;
	}
	public Animateur rechercheAnimateur (Directeur d,String Cin) {
		
		Vector<Animateur> vec = d.getListeAnimateur(); 
		int i=0;
		while (i<vec.size()) {
			if ( vec.get(i).getCin().equalsIgnoreCase(Cin)) {
				return vec.get(i);
			}
			i++;
		} 
		return null;
	}
	public void add_Ca(Directeur d) {
		int choix,choix1,i=0,code;

		Cours cou;
		Animateur a;
		System.out.println("\nDonner le nom du classe : ");
		this.nom = sr.next();	
		do {
		System.out.println("\nAjouter un cours (1 : oui / 0 : non ) : ");
		choix1 = sr.nextInt();
		}while(!(choix1 == 1 || choix1 == 0));
		if (choix1==1) {
			do {
				do {
					System.out.println("\nDonner le code du cours : ");
					code = sr.nextInt();
					
				}while((cou=rechercheCours(d,code))==null );
				cours.add(cou);
				a=rechercheAnimateur(d,cou.getCin());
				animateurs.add(rechercheAnimateur(d,cou.getCin()).getNom()+" "+rechercheAnimateur(d,cou.getCin()).getPrenom()) ;
				prix = prix +cou.getPrix();
				i++;
				do {
					System.out.println("\nAjouter un autre cours (1 : oui / 0 : non ) : ");
					choix = sr.nextInt();
				}while(!(choix == 1 || choix == 0));
			}while(choix == 1);
		}
		Vector v = d.getListeClasse();
		v.add(this);
		d.setListeClasse(v);
		System.out.println("\nAdded ");
	}

	public void delete(Directeur d) {
		
		Vector<Eleve> vect = d.getListeEleve(); 
		int i=0;
		while (i<etudiants.size()) {
			vect.remove(etudiants.get(i));
			i++;
		}		
		Vector<Classes> vec = d.getListeClasse(); 
		vec.removeElement(this);
		d.setListeClasse(vec);
	}
	public void update(Directeur d) {
		Cours cou;
		Animateur a;
		Eleve eleve;
		Classes c;
		String nom_c, cinP1,prenom1,nom1;
        int code,i=0,choix = 0;
            System.out.println(" ------------------- Mettre � jour d'une classe ----------------------------");
            System.out.println("\n\t  1- Changer le nom ");
            System.out.println("\n\t  2- Ajouter un cours ");
            System.out.println("\n\t  3- Suprimer un cours ");
            System.out.println("\n\t  4- Changer la classe d'un eleve");

            System.out.println("\nDonner le numero de votre choix : ");
            choix = sr.nextInt();
            switch (choix) {

            case 1 :	System.out.println("\nDonner le nom : ");
            			nom= sr.next();
						while (i<etudiants.size()) {
							/// vector 
							etudiants.get(i).setnClasse(nom);
							i++;
						}
                break;
            case 2 :	do {
							System.out.println("\nDonner le code du cours : ");
							code = sr.nextInt();
							
						}while((cou=rechercheCours(d,code))==null );
						cours.add(cou);
						a=rechercheAnimateur(d,cou.getCin());
						animateurs.add(rechercheAnimateur(d,cou.getCin()).getNom()+" "+rechercheAnimateur(d,cou.getCin()).getPrenom()) ;
						prix = prix +cou.getPrix();
						while (i<etudiants.size()) {
							/// vector 
							etudiants.get(i).setPrix(prix);
							i++;
						}
				break;
            case 3 :	do {
			    			System.out.println("\nDonner le code de cours : ");
			    			 code = sr.nextInt();
			    		}while ((cou=rechercheCours(d,code)) == null );
            			prix = prix -cou.getPrix();
            			while (i<etudiants.size()) {
							/// vector 
							etudiants.get(i).setPrix(prix);
							i++;
						}
            			int k=cours.indexOf(cou);
            			if (k>=0) {
            				cours.remove(cou);
            				animateurs.remove(k);
            			}				
            			
			    break;
			case 4 :	
						do {
							System.out.println("\nDonner le nom de l'eleve : ");
							 nom1 = sr.next();
							System.out.println("\nDonner le pr�nom de l'eleve : ");
							 prenom1 = sr.next();
							System.out.println("\nDonner le num�ro de CIN de son p�re : ");
							 cinP1 = sr.next();
						}while ((eleve=rechercheEleve(d,cinP1,prenom1,nom1)) == null );
						do {
							System.out.println("Donner le nom de la nouvelle classe : ");
							nom_c = sr.next();
						}while((c=rechercheClasse(d,nom_c))==null);
						if(c.getNbEleve()<20) {
							eleve.setnClasse(nom_c);
							eleve.setPrix(c.getPrix());
							c.etudiants.add(eleve);
							this.etudiants.remove(eleve);
							System.out.println("La classe est changee.");
						}else {
							System.out.println("\nLa classe est plaine ");
						}
						
				break;
			default:
                System.out.println("choix INVALIDE.\n");
                break;
            }
	}
	
	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	

	public ArrayList<Eleve> getEtudiants() {
		return etudiants;
	}


	public void setEtudiants(ArrayList<Eleve> etudiants) {
		this.etudiants = etudiants;
	}


	public ArrayList<Cours> getCours() {
		return cours;
	}


	public void setCours(ArrayList<Cours> cours) {
		this.cours = cours;
	}


	public ArrayList<String> getAnimateurs() {
		return animateurs;
	}


	public void setAnimateurs(ArrayList<String> animateurs) {
		this.animateurs = animateurs;
	

	}

	public static int getNbEleve() {
		return nbEleve;
	}
	public static void setNbEleve(int nbEleve) {
		Classes.nbEleve = nbEleve;
	}
	
	public double getPrix() {
		return prix;
	}
	public void setPrix(double prix) {
		this.prix = prix;
	}
	@Override
	public String toString() {
	   return "|         NOM         |\t\t"+nom+"\n"+
	    "+---------------------+----------------------------------------------------------------------------\n"+
	    "|       ETUDIANT      |\t\t"+etudiants+"\n"+
	    "+---------------------+----------------------------------------------------------------------------\n"+
	    "|        COURS        |\t\t"+cours+"\n"+
	    "+---------------------+----------------------------------------------------------------------------\n"+
	    "|      ANIMATEUR      |\t\t"+animateurs+"\n"+
	    "\n+-------------------------------------------------------------------------------------------------+\n"+
	    "+-------------------------------------------------------------------------------------------------+\n";



	    }
	
}
