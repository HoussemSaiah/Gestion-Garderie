package test;

import java.util.Vector;

import acteur.Classes;
import acteur.Directeur;
import acteur.Eleve;
import acteur.Garderie;

public class Main {

	public static void main(String[] args) {
		Test_Garderie t= new Test_Garderie();
		Directeur d1 = new Directeur();

		t.menu(d1);
		
	}

}
