package test;

import java.util.Scanner;
import java.util.Vector;

import acteur.Animateur;
import acteur.Classes;
import acteur.Cours;
import acteur.Directeur;
import acteur.Eleve;
import acteur.Garderie;

public class Test_Garderie {

	Garderie g = new Garderie();
	Scanner sr = new Scanner(System.in);
	
	public void menu(Directeur d) {
		int choix = 0;
		do {
			System.out.println(" ------------------- MENU PRINCIPALE ----------------------------");
			System.out.println("\n\t\t 1- Gestion Animateurs ");
            System.out.println("\n\t\t 2- Gestion �l�ves ");
            System.out.println("\n\t\t 3- Gestion Classes ");
            System.out.println("\n\t\t 4- Gestion Activit�s/Cours ");
            System.out.println("\n\t\t 5- Gestion profil ");
			System.out.println("\n\t\t 0- Quiter l'application ");
			
			System.out.println("\nDonner le numero de votre choix : ");
			choix = sr.nextInt();
			switch (choix) {
			case 0:
				System.out.println("FERMETURE de l'application ...");
				System.exit(0);
				break;
			case 1 :GestionAnimateurs(d);
				break;
			case 2 : GestionEleve(d);
				break;
			case 3 : GestionClasses(d);
				break;
			case 4 :GestionCours(d);
				break;
			case 5 :GestionProfil(d);
            	break;
			default:
				System.out.println("choix INVALIDE.\n");
				break;
			}
		}while (choix != 0);
				
	}
	
	public void GestionAnimateurs(Directeur d) {
		int choix = 0;
		do {
			System.out.println(" ------------------- MENU GESTION ANIMATEURS ----------------------------");
			System.out.println("\n\t 1- Ajouter Animateur ");
			System.out.println("\n\t 2- Mettre � jour Animateur ");
			System.out.println("\n\t 3- Supprimer Animateur ");
			System.out.println("\n\t 4- Lister les animateurs ");
			System.out.println("\n\t 0- Retour au menu ");
			
			System.out.println("\nDonner le numero de votre choix : ");
			choix = sr.nextInt();
			switch (choix) {
			case 0:
				menu(d);
				break;
			case 1 : Animateur a = new Animateur();
    			a.add(d);
				break;
			case 2 : updateAnimateur(d);
				break;
		case 3 :	deleteAnimateur(d);
				break;
			case 4 : d.list_A();
				break;
			default:
				System.out.println("choix INVALIDE.\n");
				break;
			}
		}while (choix != 0);
	}
	
	public void GestionEleve(Directeur d) {
		int choix = 0;
		do {
			System.out.println(" ------------------- MENU GESTION ELEVE ----------------------------");
			System.out.println("\n\t 1- Ajouter Eleve ");
			System.out.println("\n\t 2- Mettre � jour Eleve ");
			System.out.println("\n\t 3- Supprimer Eleve ");
			System.out.println("\n\t 4- Lister les Eleve ");
			System.out.println("\n\t 0- Retour au menu ");
			
			System.out.println("\nDonner le numero de votre choix : ");
			choix = sr.nextInt();
			switch (choix) {
			case 0:
				menu(d);
				break;
			case 1 : Eleve e = new Eleve();
					 e.add(d);
				break;
			case 2 : updateEleve(d);
				break;
			case 3 : deleteEleve(d);
				break;
			case 4 :d.list_E();
				break;
			default:
				System.out.println("choix INVALIDE.\n");
				break;
			}
		}while (choix != 0);
	}
	public void GestionClasses(Directeur d) {
        int choix = 0;
        do {
            System.out.println(" ------------------- MENU GESTION CLASSE ----------------------------");
            System.out.println("\n\t 1- Ajouter une classe ");
            System.out.println("\n\t 2- Supprimer une classe ");
            System.out.println("\n\t 3- Mettre � jour une classe ");
            System.out.println("\n\t 4- Lister les classes ");
            System.out.println("\n\t 0- Retour au menu ");

            System.out.println("\nDonner le numero de votre choix : ");
            choix = sr.nextInt();
            switch (choix) {
            case 0:
                menu(d);
                break;
            case 1 :	Classes c = new Classes();
            			c.add_Ca(d);
                break;
            case 2 : 	deleteClasses(d);
                break;
            case 3 : 	updateClasses(d);
        		break;
            case 4 :d.list_Ca();
                break;
            default:
                System.out.println("choix INVALIDE.\n");
                break;
            }
        }while (choix != 0);
    }


    public void GestionCours(Directeur d) {

        int choix = 0;
        do {
            System.out.println(" ------------------- MENU GESTION COURS ----------------------------");
            System.out.println("\n\t 1- Ajouter un cours ");
            System.out.println("\n\t 2- Supprimer un cours ");
            System.out.println("\n\t 3- Lister les cours ");
            System.out.println("\n\t 0- Retour au menu ");

            System.out.println("\nDonner le numero de votre choix : ");
            choix = sr.nextInt();
            switch (choix) {
            case 0:
                menu(d);
                break;
            case 1 :	Cours c= new Cours();
            			c.add_C(d);
                break;
            case 2 : deleteCours(d);
                break;
            case 3 :d.list_C();
                break;
            default:
                System.out.println("choix INVALIDE.\n");
                break;
            }
        }while (choix != 0);

    }
    public void GestionProfil(Directeur d) {
        int choix = 0;
        do {
            System.out.println(" ------------------- MENU GESTION Profil ----------------------------");
            System.out.println("\n\t 1- Modifier le compte ");
            System.out.println("\n\t 2- Afficher les coordonn�es de lagarderie ");
            System.out.println("\n\t 3- Modifier les coordonn�es de lagarderie ");
            System.out.println("\n\t 4- Statistique ");

            System.out.println("\n\t 0- Retour au menu ");

            System.out.println("\nDonner le numero de votre choix : ");
            choix = sr.nextInt();
            switch (choix) {
            case 0:
                menu(d);
                break;
            case 1 : 
                d.update_d();
                break;
            case 2 : 
                g.affiche();
            break;
            case 3 : 
                g.update_d();
                break;
            case 4 : 
            	d.statistique();
            	break;
            default:
                System.out.println("choix INVALIDE.\n");
                break;
            }
        }while (choix != 0);
    }
	public void authentification(Directeur d) {
		String user = "";
		String pass = "";

		do {

			System.out.println("Donner le username : ");
			user = sr.next();
			System.out.println("Donner le mot de passe : ");
			pass = sr.next();
		}while (!(d.getUserName().equalsIgnoreCase(user) && d.getPassword().equalsIgnoreCase(pass)));
		menu(d);
	}

	public Eleve existEleve(Directeur d ,String cinP,String prenom,String nom) {
		Vector<Eleve> vec = d.getListeEleve(); 
		int i=0;
		while (i<vec.size()) {
			if ( vec.get(i).getCinP().equalsIgnoreCase(cinP) && vec.get(i).getPrenom().equalsIgnoreCase(prenom) && vec.get(i).getNom().equalsIgnoreCase(nom)) {
				return vec.get(i);
			}
			i++;
		} 
		return null;
	}
	
	public void deleteEleve(Directeur d) {
		String cinP1,prenom1,nom1;
		Eleve eleve;
		do {
			System.out.println("\nDonner le nom : ");
			 nom1 = sr.next();
			System.out.println("\nDonner le pr�nom : ");
			 prenom1 = sr.next();
			System.out.println("\nDonner le num�ro de CIN de son p�re : ");
			 cinP1 = sr.next();
		}while ((eleve=existEleve(d,cinP1,prenom1,nom1)) == null );
		eleve.delete(d);
	}
	public void updateEleve(Directeur d) {
		String cinP1,prenom1,nom1;
		Eleve eleve;
		do {
			System.out.println("\nDonner le nom : ");
			 nom1 = sr.next();
			System.out.println("\nDonner le pr�nom : ");
			 prenom1 = sr.next();
			System.out.println("\nDonner le num�ro de CIN de son p�re : ");
			 cinP1 = sr.next();
		}while ((eleve=existEleve(d,cinP1,prenom1,nom1)) == null );
		eleve.update(d);;
	}
	
	public Classes existClasses(Directeur d ,String nom) {
		Vector<Classes> vec = d.getListeClasse(); 
		int i=0;
		while (i<vec.size()) {
			if (vec.get(i).getNom().equalsIgnoreCase(nom)) {
				return vec.get(i);
			}
			i++;
		} 
		return null;
	}
	
	public void deleteClasses(Directeur d) {
		String nom1;
		Classes classe;
		do {
			System.out.println("\nDonner le nom de la classe : ");
			 nom1 = sr.next();
		}while ((classe=existClasses(d,nom1)) == null );
		classe.delete(d);
	}
	public void updateClasses(Directeur d) {
		String nom1;
		Classes classe;
		do {
			System.out.println("\nDonner le nom de la classe : ");
			 nom1 = sr.next();
		}while ((classe=existClasses(d,nom1)) == null );
		classe.update(d);
	}
	
	public Cours existCours(Directeur d ,int code) {
		Vector<Cours> vec = d.getListeCours(); 
		int i=0;
		while (i<vec.size()) {
			if (vec.get(i).getCode() == code) {
				return vec.get(i);
			}
			i++;
		} 
		return null;
	}
	
	public void deleteCours(Directeur d) {
		int code ;
		Cours cours;
		do {
			System.out.println("\nDonner le code de cours : ");
			 code = sr.nextInt();
		}while ((cours=existCours(d,code)) == null );
		cours.delete(d);
	}
	
	public Animateur existAnimateur(Directeur d ,String cin) {
		Vector<Animateur> vec = d.getListeAnimateur(); 
		int i=0;
		while (i<vec.size()) {
			if (vec.get(i).getCin().equalsIgnoreCase(cin) ){
				return vec.get(i);
			}
			i++;
		} 
		return null;
	}
	
	public void deleteAnimateur(Directeur d) {
		String cin;
		Animateur animateur;
		do {
			System.out.println("\nDonner le CIN : ");
			cin = sr.next();
		}while ((animateur=existAnimateur(d,cin)) == null );
		animateur.delete(d);
	}
	public void updateAnimateur(Directeur d) {
		String cin;
		Animateur animateur;
		do {
			System.out.println("\nDonner le CIN : ");
			cin = sr.next();
		}while ((animateur=existAnimateur(d,cin)) == null );
		animateur.update(d);
	}
}